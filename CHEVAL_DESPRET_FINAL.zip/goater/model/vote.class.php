<?php
    class vote extends basemodel {

    }
