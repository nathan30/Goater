<?php
    class post extends basemodel {

    }