<?php
    context::setSessionAttribute("connect","false");
    context::redirect("?action=login");
?>
